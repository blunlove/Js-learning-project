<template>
    <div>
        <h1>共同header</h1>
        <img src="../assets/imgs/logo.png">
    </div>
</template>

